/**
 * Cursor overlay management
 */
import { COLORS, Z_INDEX } from '../config/constants.js';

export class CursorManager {
  constructor() {
    this.cursorEl = null;
    this.lastPosition = { x: 0, y: 0 };
    this.isStuck = false;
    this.stuckCheckInterval = null;
    this.forceUpdateCount = 0;
    this.currentMode = null; // Cache current mode to avoid unnecessary updates
    this.uriCache = new Map(); // Cache generated URIs
  }

  ensure() {
    if (this.cursorEl) return;

    // Check if early injection cursor exists and clean it up
    const existingCursor = document.getElementById('kpv2-cursor');
    if (existingCursor && window.KEYPILOT_EARLY) {
      // Remove early cursor element since we're using CSS cursor now
      existingCursor.remove();
      
      // Get the current position from early injection
      const earlyPosition = window.KEYPILOT_EARLY.getPosition();
      this.lastPosition = earlyPosition;
      
      // Notify early injection that main extension has loaded
      window.dispatchEvent(new CustomEvent('keypilot-main-loaded'));
      
      if (window.KEYPILOT_DEBUG) {
        console.log('[KeyPilot] Took over from early injection, using CSS cursor');
      }
    }

    // Mark cursor as initialized (using CSS cursor, no DOM element needed)
    this.cursorEl = { style: {} }; // Dummy object for compatibility
    
    // Apply CSS cursor to document
    this.setMode('none', {});
  }

  setMode(mode, options = {}) {
    if (!this.cursorEl) return;

    // Skip if mode hasn't changed to avoid unnecessary CSS updates
    if (this.currentMode === mode) {
      return;
    }

    this.currentMode = mode;

    // Always set cursor to ensure it works over links and other elements
    const cursorUri = this.getCursorDataUri(mode, options);
    const cursorValue = `url("${cursorUri}") 30 30, auto`;

    console.log('setMode: cursorValue', cursorValue);
    // Set cursor using CSS variable on document element
    // The StyleManager has a global rule to apply this to all elements
    document.documentElement.style.setProperty('--kpv2-cursor', cursorValue);

    // Clean up direct styles if they exist - they can interfere with the variable
    if (document.documentElement.style.cursor) document.documentElement.style.cursor = '';
    if (document.body.style.cursor) document.body.style.cursor = '';
  }


  updatePosition(x, y) {
    if (!this.cursorEl) return;
    // CSS cursor doesn't need position updates - browser handles it automatically
    // This method is kept for API compatibility but does nothing
    this.lastPosition = { x, y };
  }

  getCurrentMode() {
    return this.currentMode || 'none';
  }

  /**
   * Generate SVG data URI for cursor mode
   */
  getCursorDataUri(mode, options = {}) {
    // Extract parameters with defaults
    const {
      crossHairQuadrantWidth = 15,
      distanceFromCenter = 8,
      strokeLineCap = 'round',
      strokeWidth = 4,
      crossHairScalingFactor = 1
    } = options;

    // Apply scaling factor
    const scaledDistance = distanceFromCenter * crossHairScalingFactor;
    const scaledWidth = crossHairQuadrantWidth * crossHairScalingFactor;

    // Calculate segment positions (center is now at 30,30 for 60x60 canvas)
    const centerX = 30;
    const centerY = 30;
    const segmentStart = centerY - scaledDistance - scaledWidth;
    const segmentEnd = centerY - scaledDistance;
    const segmentStart2 = centerY + scaledDistance;
    const segmentEnd2 = centerY + scaledDistance + scaledWidth;

    const cacheKey = `${mode}-${crossHairQuadrantWidth}-${distanceFromCenter}-${strokeLineCap}-${strokeWidth}-${crossHairScalingFactor}`;
    if (this.uriCache.has(cacheKey)) {
      return this.uriCache.get(cacheKey);
    }

    let svgContent = '';

    if (mode === 'text_focus') {
      // Orange crosshair
      const color = COLORS.ORANGE;
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" width="60" height="60">
        <line x1="30" y1="${segmentStart}" x2="30" y2="${segmentEnd}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="30" y1="${segmentStart2}" x2="30" y2="${segmentEnd2}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart}" y1="30" x2="${segmentEnd}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart2}" y1="30" x2="${segmentEnd2}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
      </svg>`;
    } else if (mode === 'delete') {
      // Red X - scaled for 60x60 canvas
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" width="60" height="60">
        <line x1="12" y1="12" x2="48" y2="48" stroke="${COLORS.DELETE_RED}" stroke-width="5" stroke-linecap="round"/>
        <line x1="48" y1="12" x2="12" y2="48" stroke="${COLORS.DELETE_RED}" stroke-width="5" stroke-linecap="round"/>
      </svg>`;
    } else if (mode === 'highlight') {
      // Blue crosshair
      const color = COLORS.HIGHLIGHT_BLUE;
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" width="60" height="60">
        <line x1="30" y1="${segmentStart}" x2="30" y2="${segmentEnd}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="30" y1="${segmentStart2}" x2="30" y2="${segmentEnd2}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart}" y1="30" x2="${segmentEnd}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart2}" y1="30" x2="${segmentEnd2}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
      </svg>`;
    } else {
      // Default green crosshair
      const color = COLORS.FOCUS_GREEN_BRIGHT;
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" width="60" height="60">
        <line x1="30" y1="${segmentStart}" x2="30" y2="${segmentEnd}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="30" y1="${segmentStart2}" x2="30" y2="${segmentEnd2}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart}" y1="30" x2="${segmentEnd}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
        <line x1="${segmentStart2}" y1="30" x2="${segmentEnd2}" y2="30" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="${strokeLineCap}"/>
      </svg>`;
    }

    // Convert to data URI
    const encoded = encodeURIComponent(svgContent);
    const uri = `data:image/svg+xml,${encoded}`;
    this.uriCache.set(cacheKey, uri);
    return uri;
  }

  hide() {
    if (this.cursorEl) {
      // Hide cursor by setting the CSS variable to default
      document.documentElement.style.setProperty('--kpv2-cursor', 'default');
    }
  }

  show() {
    if (this.cursorEl) {
      // Show cursor by restoring current mode
      const currentMode = this.getCurrentMode();
      // Reset currentMode to force update in setMode
      const oldMode = this.currentMode;
      this.currentMode = null; 
      this.setMode(currentMode, {});
    }
  }





  cleanup() {
    if (this.stuckCheckInterval) {
      clearInterval(this.stuckCheckInterval);
      this.stuckCheckInterval = null;
    }

    // Remove CSS cursor
    document.documentElement.style.cursor = '';
    document.body.style.cursor = '';
    // Also remove the CSS variable
    document.documentElement.style.removeProperty('--kpv2-cursor');
    
    this.cursorEl = null;
    this.currentMode = null; // Reset mode so setMode will update when re-enabled
  }

  createElement(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (v == null) continue;
      if (k === 'className') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v);
    }
    for (const c of children) {
      if (c == null) continue;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  }
}