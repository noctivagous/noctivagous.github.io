/**
 * Build script for KeyPilot extension
 */
import fs from 'fs';
import path from 'path';
import { minify } from 'terser';
import { KEYBINDINGS, Z_INDEX } from './src/config/constants.js';
import {
  KEYBINDINGS_KEYBOARD_LAYOUT,
  KEYBINDINGS_UI_STYLE_ATTR,
  getKeybindingsUiCss
} from './src/ui/keybindings-ui-shared.js';

console.log('Starting build...');

function getBuildTimestamp(now = new Date()) {
  // Format date as: Mar-14-2026-4:20PM
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[now.getMonth()];
  const day = now.getDate();
  const year = now.getFullYear();
  let hours = now.getHours();
  const minutes = now.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  const minutesStr = minutes.toString().padStart(2, '0');
  return `${month}-${day}-${year}-${hours}:${minutesStr}${ampm}`;
}

const modules = [
  'src/config/constants.js',
  'src/modules/state-manager.js',
  'src/modules/event-manager.js',
  'src/modules/cursor.js',
  'src/modules/element-detector.js',
  'src/modules/activation-handler.js',
  'src/modules/focus-detector.js',
  'src/modules/mouse-coordinate-manager.js',
  'src/modules/highlight-manager.js',
  'src/modules/overlay-manager.js',
  'src/modules/style-manager.js',
  'src/modules/shadow-dom-manager.js',
  'src/modules/intersection-observer-manager.js',
  'src/modules/optimized-scroll-manager.js',
  'src/modules/keypilot-toggle-handler.js',
  'src/modules/text-element-filter.js',
  'src/modules/edge-character-detector.js',
  'src/modules/rectangle-intersection-observer.js',
  // UI modules used by the content script (must appear before keypilot.js so symbols exist after imports are stripped)
  'src/ui/keybindings-ui-shared.js',
  'src/ui/keybindings-ui.js',
  'src/ui/floating-keyboard-help.js',
  'src/keypilot.js',
  'src/content-script.js'
];

// Validate all source files exist before bundling
console.log('Validating source files...');
for (const modulePath of modules) {
  if (!fs.existsSync(modulePath)) {
    console.error(`ERROR: Source file not found: ${modulePath}`);
    process.exit(1);
  }
}
console.log('All source files validated successfully.');

let bundledContent = `/**
 * KeyPilot Chrome Extension - Bundled Version
 * Generated on ${new Date().toISOString()}
 */

(() => {
  // Global scope for bundled modules

`;

for (const modulePath of modules) {
  console.log(`Processing ${modulePath}...`);
  let moduleContent = fs.readFileSync(modulePath, 'utf8');
  
  // Remove imports and exports
  moduleContent = moduleContent
    // Remove ESM imports (single-line and multi-line) because we bundle into one IIFE.
    // Note: `.*?` doesn't cross newlines, so use `[\s\S]*?` to handle multi-line imports.
    .replace(/import\s+[\s\S]*?from\s+['"][^'"]*['"];?\s*\n?/g, '')
    // Remove side-effect imports: `import './x.js';`
    .replace(/import\s+['"][^'"]*['"];?\s*\n?/g, '')
    .replace(/^export\s+(class|function|const|let|var)\s+/gm, '$1 ')
    // Handle re-export syntax: `export { X } from './mod.js';`
    .replace(/export\s*\{[^}]*\}\s*from\s+['"][^'"]*['"];?\s*\n?/g, '')
    .replace(/export\s*\{[^}]*\}\s*;?\s*\n?/g, '')
    .replace(/^export\s+/gm, '');
  
  bundledContent += `
  // Module: ${modulePath}
${moduleContent}

`;
}

bundledContent += `
})();
`;

// Generate content-bundled.js in extension directory
fs.writeFileSync('content-bundled.js', bundledContent);
console.log('Generated content-bundled.js in extension directory');

// Check for minification flag
const shouldMinify = process.argv.includes('--minify') || process.argv.includes('-m');

if (shouldMinify) {
  console.log('Minifying bundle with Terser...');

  try {
    const minifyOptions = {
      compress: {
        drop_console: false, // Keep console.log for debugging
        drop_debugger: true,
        pure_funcs: [], // Don't remove any functions
      },
      mangle: {
        reserved: ['KeyPilot', 'chrome', 'document', 'window'], // Don't mangle these names
      },
      format: {
        comments: false, // Remove comments
      },
    };

    const minifiedResult = await minify(bundledContent, minifyOptions);

    if (minifiedResult.error) {
      console.error('Terser minification error:', minifiedResult.error);
      process.exit(1);
    }

    // Write minified version
    fs.writeFileSync('content-bundled.min.js', minifiedResult.code);

    const originalSize = (bundledContent.length / 1024).toFixed(1);
    const minifiedSize = (minifiedResult.code.length / 1024).toFixed(1);
    const compressionRatio = (((bundledContent.length - minifiedResult.code.length) / bundledContent.length) * 100).toFixed(1);

    console.log(`✓ Generated content-bundled.min.js (${minifiedSize}KB, ${compressionRatio}% reduction from ${originalSize}KB)`);

  } catch (error) {
    console.error('Minification failed:', error.message);
    process.exit(1);
  }
}

// Validate background.js exists in extension directory
if (fs.existsSync('background.js')) {
  console.log('background.js found and ready for extension');
} else {
  console.error('ERROR: background.js not found in extension directory! Extension will not work properly.');
  process.exit(1);
}

/**
 * README Key Mappings Generator
 *
 * We keep docs in sync with the real keybindings in `src/config/constants.js`.
 * Only the section between the markers is overwritten.
 */
const README_MARKER_START = '<!-- KP_KEY_MAPPINGS_START -->';
const README_MARKER_END = '<!-- KP_KEY_MAPPINGS_END -->';

function formatInlineCode(text) {
  // Special-case backtick so it renders correctly in markdown.
  if (text === '`') return '`` ` ``';
  // If key label itself contains backticks, fall back to plain text.
  if (String(text).includes('`')) return String(text);
  return `\`${String(text)}\``;
}

function formatKeysLabel(displayKey) {
  if (!displayKey) return '';
  const str = String(displayKey).trim();
  // Common pattern in this codebase: "1 or /"
  if (str.includes(' or ')) {
    return str
      .split(' or ')
      .map((part) => formatInlineCode(part.trim()))
      .join(' or ');
  }
  return formatInlineCode(str);
}

function actionCategory(actionId) {
  if (!actionId) return 'Other';
  if (actionId.startsWith('PAGE_')) return 'Page navigation';
  if (actionId === 'TAB_LEFT' || actionId === 'TAB_RIGHT' || actionId === 'NEW_TAB' || actionId === 'CLOSE_TAB') return 'Tabs';
  if (actionId === 'DELETE' || actionId === 'CANCEL' || actionId === 'HIGHLIGHT' || actionId === 'RECTANGLE_HIGHLIGHT' || actionId === 'TOGGLE_KEYBOARD_HELP') {
    return 'Modes & UI';
  }
  return 'Navigation';
}

function buildKeyMappingsMarkdown({ keybindings, manifest }) {
  const rows = Object.entries(keybindings || {}).map(([id, b]) => {
    const keys = formatKeysLabel(b.displayKey || b.keyLabel || (Array.isArray(b.keys) ? b.keys.join(' / ') : ''));
    const action = String(b.description || b.label || id);
    const sortRow = typeof b.row === 'number' ? b.row : 99;
    return { id, keys, action, sortRow, category: actionCategory(id) };
  });

  // Stable sort: category, row, keys, id
  const categoryOrder = ['Navigation', 'Tabs', 'Page navigation', 'Modes & UI', 'Other'];
  rows.sort((a, b) => {
    const ca = categoryOrder.indexOf(a.category);
    const cb = categoryOrder.indexOf(b.category);
    if (ca !== cb) return (ca === -1 ? 999 : ca) - (cb === -1 ? 999 : cb);
    if (a.sortRow !== b.sortRow) return a.sortRow - b.sortRow;
    const k = String(a.keys).localeCompare(String(b.keys));
    if (k !== 0) return k;
    return String(a.id).localeCompare(String(b.id));
  });

  const byCategory = new Map();
  for (const r of rows) {
    if (!byCategory.has(r.category)) byCategory.set(r.category, []);
    byCategory.get(r.category).push(r);
  }

  const globalRows = [];
  const commands = (manifest && manifest.commands) || {};
  for (const [commandId, cmd] of Object.entries(commands)) {
    const suggested = cmd && cmd.suggested_key && cmd.suggested_key.default;
    const keys = suggested ? formatInlineCode(suggested) : '';
    const action = cmd && cmd.description ? String(cmd.description) : `Command: ${commandId}`;
    if (keys) globalRows.push({ keys, action });
  }

  let out = '';
  out += `${README_MARKER_START}\n`;
  out += `> Generated by \`extension/build.js\` from \`extension/src/config/constants.js\` and \`extension/manifest.json\`. Do not edit by hand.\n\n`;

  for (const category of categoryOrder) {
    const catRows = byCategory.get(category);
    if (!catRows || catRows.length === 0) continue;
    out += `#### ${category}\n\n`;
    out += `| Keys | Action |\n`;
    out += `| --- | --- |\n`;
    for (const r of catRows) {
      out += `| ${r.keys} | ${r.action} |\n`;
    }
    out += `\n`;
  }

  if (globalRows.length) {
    out += `#### Global shortcuts\n\n`;
    out += `| Keys | Action |\n`;
    out += `| --- | --- |\n`;
    for (const r of globalRows) {
      out += `| ${r.keys} | ${r.action} |\n`;
    }
    out += `\n`;
  }

  out += `${README_MARKER_END}\n`;
  return out;
}

function replaceMarkedSection(fileContent, newSection) {
  const startIdx = fileContent.indexOf(README_MARKER_START);
  const endIdx = fileContent.indexOf(README_MARKER_END);
  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    return (
      fileContent.slice(0, startIdx) +
      newSection +
      fileContent.slice(endIdx + README_MARKER_END.length) // marker already included in newSection
    );
  }
  return null;
}

function ensureKeyMappingsSectionExists(readmeContent) {
  // Insert a "Key Mappings" header with empty markers under "Key Features" if possible.
  const header = '### ⌨️ Key Mappings';
  if (readmeContent.includes(README_MARKER_START) && readmeContent.includes(README_MARKER_END)) return readmeContent;
  if (readmeContent.includes(header)) {
    return readmeContent.replace(
      header,
      `${header}\n\n${README_MARKER_START}\n${README_MARKER_END}\n`
    );
  }

  const keyFeaturesIdx = readmeContent.indexOf('## ✨ Key Features');
  if (keyFeaturesIdx !== -1) {
    const insertAt = readmeContent.indexOf('\n', keyFeaturesIdx);
    if (insertAt !== -1) {
      return (
        readmeContent.slice(0, insertAt + 1) +
        `\n${header}\n\n${README_MARKER_START}\n${README_MARKER_END}\n\n` +
        readmeContent.slice(insertAt + 1)
      );
    }
  }

  // Fallback: append to end.
  return (
    `${readmeContent.trimEnd()}\n\n${header}\n\n${README_MARKER_START}\n${README_MARKER_END}\n`
  );
}

function updateReadmeFile({ readmePath, keybindings, manifest }) {
  try {
    if (!fs.existsSync(readmePath)) return;
    let content = fs.readFileSync(readmePath, 'utf8');
    content = ensureKeyMappingsSectionExists(content);
    const section = buildKeyMappingsMarkdown({ keybindings, manifest });

    const replaced = replaceMarkedSection(content, section);
    if (replaced === null) {
      console.warn(`WARN: Could not find markers in README to replace: ${readmePath}`);
      return;
    }
    if (replaced !== content) {
      fs.writeFileSync(readmePath, replaced, 'utf8');
      console.log(`✓ Updated README key mappings: ${readmePath}`);
    } else {
      console.log(`README key mappings already up-to-date: ${readmePath}`);
    }
  } catch (err) {
    console.warn(`WARN: Failed to update README key mappings for ${readmePath}:`, err && err.message ? err.message : err);
  }
}

/**
 * Website index.html generator
 *
 * Stamps:
 * - Build timestamp (under the download button)
 * - Key bindings tiles (between markers)
 */
const WEBSITE_TS_MARKER_START = '<!-- KP_WEBSITE_BUILD_TIMESTAMP_START -->';
const WEBSITE_TS_MARKER_END = '<!-- KP_WEBSITE_BUILD_TIMESTAMP_END -->';
const WEBSITE_KEYS_MARKER_START = '<!-- KP_WEBSITE_KEY_BINDINGS_START -->';
const WEBSITE_KEYS_MARKER_END = '<!-- KP_WEBSITE_KEY_BINDINGS_END -->';
const WEBSITE_BINDINGS_ATTR_RE = /data-kp-website-bindings\s*=\s*"([^"]*)"/i;
const POPUP_VERSION_RE = /(<span[^>]*class=["']version["'][^>]*>)([\s\S]*?)(<\/span>)/i;

function escapeHtml(s) {
  return String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function replaceInnerBetweenMarkers(fileContent, startMarker, endMarker, newInner) {
  const startIdx = fileContent.indexOf(startMarker);
  const endIdx = fileContent.indexOf(endMarker);
  if (startIdx === -1 || endIdx === -1 || endIdx < startIdx) return null;
  const innerStart = startIdx + startMarker.length;
  return fileContent.slice(0, innerStart) + String(newInner) + fileContent.slice(endIdx);
}

/**
 * early-inject.js UI sync generator
 *
 * `early-inject.js` is loaded directly by the manifest at `document_start`,
 * so it cannot import ESM. We keep its duplicated UI constants in sync by
 * stamping a generated block between markers.
 */
const EARLY_UI_MARKER_START = '// KP_EARLY_INJECT_UI_START';
const EARLY_UI_MARKER_END = '// KP_EARLY_INJECT_UI_END';

function pickEarlyBindingFields(binding) {
  if (!binding) return null;
  return {
    label: binding.label,
    description: binding.description,
    keyLabel: binding.keyLabel,
    displayKey: binding.displayKey,
    keyboardClass: binding.keyboardClass
  };
}

function collectActionIdsFromLayout(layout) {
  const ids = new Set();
  for (const row of layout || []) {
    for (const item of row || []) {
      if (item && item.type === 'action' && item.id) ids.add(String(item.id));
    }
  }
  return ids;
}

function updateEarlyInjectUiBlock() {
  const earlyPath = path.resolve(process.cwd(), 'early-inject.js');
  if (!fs.existsSync(earlyPath)) {
    console.warn(`WARN: early-inject.js not found at: ${earlyPath}`);
    return;
  }

  const layout = KEYBINDINGS_KEYBOARD_LAYOUT;
  const actionIds = collectActionIdsFromLayout(layout);
  // Keep legacy/non-layout entries too (used elsewhere / future-proofing).
  actionIds.add('TOGGLE_KEYBOARD_HELP');

  const earlyKeybindings = {};
  for (const id of actionIds) {
    const picked = pickEarlyBindingFields(KEYBINDINGS[id]);
    if (picked) earlyKeybindings[id] = picked;
  }

  const css = getKeybindingsUiCss({ zKeybindingsPopover: Z_INDEX.KEYBINDINGS_POPOVER });
  const escapedCss = String(css).replaceAll('`', '\\`');

  const generatedInner =
    `\n` +
    `  // NOTE: This block is auto-generated by \`extension/build.js\` from:\n` +
    `  // - \`extension/src/config/constants.js\` (KEYBINDINGS, Z_INDEX)\n` +
    `  // - \`extension/src/ui/keybindings-ui-shared.js\` (CSS + layout + style attr)\n` +
    `  // Do not edit by hand.\n` +
    `  const Z_FLOATING_KEYBOARD_HELP = ${Number(Z_INDEX.FLOATING_KEYBOARD_HELP)};\n` +
    `  const Z_KEYBINDINGS_POPOVER = ${Number(Z_INDEX.KEYBINDINGS_POPOVER)};\n` +
    `  const KEYBINDINGS_UI_STYLE_ATTR = ${JSON.stringify(KEYBINDINGS_UI_STYLE_ATTR)};\n` +
    `  const KEYBINDINGS_KEYBOARD_LAYOUT = ${JSON.stringify(layout, null, 2)};\n` +
    `  const EARLY_KEYBINDINGS = ${JSON.stringify(earlyKeybindings, null, 2)};\n` +
    `  const KEYBINDINGS_UI_EARLY_CSS = \`${escapedCss}\`;\n`;

  const content = fs.readFileSync(earlyPath, 'utf8');
  const next = replaceInnerBetweenMarkers(content, EARLY_UI_MARKER_START, EARLY_UI_MARKER_END, generatedInner);
  if (next === null) {
    throw new Error(
      `early-inject.js is missing UI markers (${EARLY_UI_MARKER_START} / ${EARLY_UI_MARKER_END}).`
    );
  }

  if (next !== content) {
    fs.writeFileSync(earlyPath, next, 'utf8');
    console.log(`✓ Updated early-inject.js UI block: ${earlyPath}`);
  } else {
    console.log('early-inject.js UI block already up-to-date');
  }
}

function formatWebsiteKeyLabel(text) {
  const str = String(text || '').trim();
  return str || '';
}

function buildWebsiteBindingItemHtml({ keys, title, subtitle, indent = '                    ' }) {
  const k = escapeHtml(keys);
  const t = escapeHtml(title);
  const s = escapeHtml(subtitle);
  return (
    `${indent}<div class="binding-item">\n` +
    `${indent}    <span class="key">${k}</span>\n` +
    `${indent}    <div class="binding-description">\n` +
    `${indent}        <strong>${t}</strong><br>\n` +
    `${indent}        <small>${s}</small>\n` +
    `${indent}    </div>\n` +
    `${indent}</div>`
  );
}

function buildWebsiteKeyBindingsInnerHtml({ keybindings, manifest, ids }) {
  const out = [];
  const commands = (manifest && manifest.commands) || {};

  for (const rawId of ids || []) {
    const id = String(rawId || '').trim();
    if (!id) continue;

    if (id.startsWith('command:')) {
      const commandId = id.slice('command:'.length).trim();
      const cmd = commands[commandId];
      if (!cmd) {
        console.warn(`WARN: Website key bindings requested unknown command: ${commandId}`);
        continue;
      }
      const keys = formatWebsiteKeyLabel(cmd && cmd.suggested_key && cmd.suggested_key.default);
      const title = (cmd && cmd.description) ? String(cmd.description) : `Command: ${commandId}`;
      const subtitle = 'Global shortcut';
      out.push(buildWebsiteBindingItemHtml({ keys, title, subtitle }));
      continue;
    }

    const binding = keybindings && keybindings[id];
    if (!binding) {
      console.warn(`WARN: Website key bindings requested unknown KEYBINDINGS id: ${id}`);
      continue;
    }

    const keys = formatWebsiteKeyLabel(binding.displayKey || binding.keyLabel || (Array.isArray(binding.keys) ? binding.keys.join(' / ') : ''));
    const title = String(binding.label || id);
    const subtitle = String(binding.description || binding.label || id);
    out.push(buildWebsiteBindingItemHtml({ keys, title, subtitle }));
  }

  // Keep a trailing newline so the closing marker stays on its own line.
  return `\n${out.join('\n')}\n                    `;
}

function updateWebsiteIndexFile({ timestamp, keybindings, manifest }) {
  const websiteIndexPath = path.resolve(process.cwd(), '..', '..', 'website', 'index.html');
  try {
    if (!fs.existsSync(websiteIndexPath)) return;
    let content = fs.readFileSync(websiteIndexPath, 'utf8');

    // Timestamp
    const stampedTs = replaceInnerBetweenMarkers(content, WEBSITE_TS_MARKER_START, WEBSITE_TS_MARKER_END, timestamp);
    if (stampedTs === null) {
      console.warn(`WARN: Could not find website timestamp markers in: ${websiteIndexPath}`);
    } else {
      content = stampedTs;
    }

    // Key bindings tiles
    const attrMatch = content.match(WEBSITE_BINDINGS_ATTR_RE);
    const ids = attrMatch && attrMatch[1]
      ? attrMatch[1].split(',').map((s) => s.trim()).filter(Boolean)
      : ['DELETE', 'ACTIVATE', 'BACK', 'FORWARD', 'CANCEL', 'command:toggle-extension'];

    const bindingsInner = buildWebsiteKeyBindingsInnerHtml({ keybindings, manifest, ids });
    const stampedBindings = replaceInnerBetweenMarkers(content, WEBSITE_KEYS_MARKER_START, WEBSITE_KEYS_MARKER_END, bindingsInner);
    if (stampedBindings === null) {
      console.warn(`WARN: Could not find website key bindings markers in: ${websiteIndexPath}`);
    } else {
      content = stampedBindings;
    }

    fs.writeFileSync(websiteIndexPath, content, 'utf8');
    console.log(`✓ Updated website index: ${websiteIndexPath}`);
  } catch (err) {
    console.warn(`WARN: Failed to update website index ${websiteIndexPath}:`, err && err.message ? err.message : err);
  }
}

function updatePopupHtmlFile({ version }) {
  const popupPath = path.resolve(process.cwd(), 'popup.html');
  try {
    if (!fs.existsSync(popupPath)) return;
    const content = fs.readFileSync(popupPath, 'utf8');
    if (!POPUP_VERSION_RE.test(content)) {
      console.warn(`WARN: Could not find <span class="version">…</span> in: ${popupPath}`);
      return;
    }
    const next = content.replace(POPUP_VERSION_RE, (_m, open, _inner, close) => `${open}${escapeHtml(version)}${close}`);
    if (next !== content) {
      fs.writeFileSync(popupPath, next, 'utf8');
      console.log(`✓ Updated popup version: ${popupPath} -> ${version}`);
    } else {
      console.log(`Popup version already up-to-date: ${popupPath}`);
    }
  } catch (err) {
    console.warn(`WARN: Failed to update popup version in ${popupPath}:`, err && err.message ? err.message : err);
  }
}

// Update manifest.json description with build date/time
console.log('Updating manifest.json with build timestamp...');
const manifestPath = 'manifest.json';
let manifestForDocs = null;

try {
  const manifestContent = fs.readFileSync(manifestPath, 'utf8');
  const manifest = JSON.parse(manifestContent);

  // Validate required fields exist
  if (!manifest.version) {
    throw new Error('manifest.json is missing required "version" field');
  }
  if (typeof manifest.version !== 'string') {
    throw new Error('manifest.json "version" field must be a string');
  }

  // Store original values for safety
  const originalVersion = manifest.version;
  const originalName = manifest.name;

  const timestamp = getBuildTimestamp(new Date());

  // Get original description and strip any existing timestamp
  // Timestamp pattern: "MMM-DD-YYYY-HH:MMAM/PM " at the start
  let originalDescription = manifest.description || '';
  // Remove any existing timestamp pattern at the beginning
  originalDescription = originalDescription.replace(/^[A-Z][a-z]{2}-\d{1,2}-\d{4}-\d{1,2}:\d{2}(AM|PM)\s+/, '');

  // ONLY modify description field
  manifest.description = `${timestamp} ${originalDescription}`;

  // Ensure version and name are not accidentally modified
  manifest.version = originalVersion;
  manifest.name = originalName;

  // Write updated manifest with proper formatting (4 spaces indentation)
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 4) + '\n');
  console.log(`✓ Updated manifest.json description with timestamp: ${timestamp}`);
  manifestForDocs = manifest;

  // Keep the website landing page in sync with the build + keybindings
  console.log('Updating website index.html...');
  updateWebsiteIndexFile({ timestamp, keybindings: KEYBINDINGS, manifest: manifestForDocs });

  console.log('Updating popup.html version...');
  updatePopupHtmlFile({ version: manifestForDocs.version });
} catch (error) {
  console.error('ERROR: Failed to update manifest.json:', error.message);
  process.exit(1);
}

// Update README key mappings (extension README + project README)
console.log('Updating README key mappings...');
{
  const extensionReadme = path.resolve(process.cwd(), 'README.md');
  const projectReadme = path.resolve(process.cwd(), '..', 'README.md');
  updateReadmeFile({ readmePath: extensionReadme, keybindings: KEYBINDINGS, manifest: manifestForDocs });
  updateReadmeFile({ readmePath: projectReadme, keybindings: KEYBINDINGS, manifest: manifestForDocs });
}

// Keep early-inject.js UI constants in sync with the canonical sources
console.log('Updating early-inject.js UI block...');
updateEarlyInjectUiBlock();

console.log('Build complete! Extension files ready:');
console.log('  - content-bundled.js (content script)');
if (shouldMinify) {
  console.log('  - content-bundled.min.js (minified content script)');
}
console.log('  - background.js (service worker)');
console.log('  - manifest.json (updated with build timestamp)');