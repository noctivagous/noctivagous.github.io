/**
 * Floating keyboard reference panel (content-script friendly).
 *
 * Shows KeyPilot's keyboard visualization in a small, fixed-position panel.
 *
 * Note: This is intentionally implemented in light DOM (no shadow root) because
 * `renderKeybindingsKeyboard()` injects its CSS into `document.head`.
 */
import { renderKeybindingsKeyboard } from './keybindings-ui.js';
import { Z_INDEX } from '../config/constants.js';

const POPUP_THEME_VARS = {
  '--fg': '#f8fafc',
  '--bg': '#0f172a',
  '--surface': '#1e293b',
  '--surface-light': '#334155',
  '--muted': '#94a3b8',
  '--ok': '#10b981',
  '--warn': '#f59e0b',
  '--err': '#44c7ef',
  '--brand': '#3b82f6',
  '--brand-dark': '#1e40af',
  '--border': '#334155',
  '--border2': '#4d617b'
};

function applyPopupThemeVars(targetEl) {
  if (!targetEl || !targetEl.style) return;
  try {
    for (const [k, v] of Object.entries(POPUP_THEME_VARS)) {
      targetEl.style.setProperty(k, v);
    }
  } catch { /* ignore */ }
}

export class FloatingKeyboardHelp {
  /**
   * @param {Object} params
   * @param {Record<string, any>} params.keybindings
   */
  constructor({ keybindings } = {}) {
    this.keybindings = keybindings || {};
    this.root = null;
    this.keyboardContainer = null;
    this.closeBtn = null;
    this._onCloseClick = this._onCloseClick.bind(this);
  }

  setKeybindings(keybindings) {
    this.keybindings = keybindings || {};
    if (this.root && !this.root.hidden) {
      this._render();
    }
  }

  isVisible() {
    return !!(this.root && this.root.isConnected && this.root.hidden === false);
  }

  show() {
    // Never show inside iframes (avoids duplicating the panel in popover iframes).
    if (window !== window.top) return;
    this._ensure();
    this.root.hidden = false;
    this._render();
  }

  hide() {
    if (this.root) this.root.hidden = true;
  }

  toggle() {
    if (this.isVisible()) this.hide();
    else this.show();
  }

  cleanup() {
    try {
      if (this.closeBtn) this.closeBtn.removeEventListener('click', this._onCloseClick);
    } catch { /* ignore */ }
    try {
      if (this.root && this.root.parentNode) this.root.parentNode.removeChild(this.root);
    } catch { /* ignore */ }
    this.root = null;
    this.keyboardContainer = null;
    this.closeBtn = null;
  }

  _ensure() {
    if (this.root && this.root.isConnected) return;

    // If early-inject created the shell at document_start, adopt it to avoid flicker.
    try {
      const existing = document.querySelector('.kp-floating-keyboard-help[data-kp-early-floating-keyboard="true"]');
      if (existing && existing.isConnected) {
        const keyboardContainer = existing.querySelector('.kp-floating-keyboard-help__keyboard');
        const closeBtn =
          existing.querySelector('button[data-kp-floating-keyboard-close="true"]') ||
          existing.querySelector('button[aria-label="Close keyboard reference"]');

        // Ensure the current z-index matches centralized constants (in case early-inject drifts).
        try {
          existing.style.zIndex = String(Z_INDEX.FLOATING_KEYBOARD_HELP);
        } catch { /* ignore */ }
        // Match popup.html theme tokens so the floating keyboard looks identical.
        applyPopupThemeVars(existing);

        if (keyboardContainer) {
          this.root = existing;
          this.keyboardContainer = keyboardContainer;
          this.closeBtn = closeBtn || null;
          if (this.closeBtn) {
            try {
              this.closeBtn.removeEventListener('click', this._onCloseClick);
            } catch { /* ignore */ }
            this.closeBtn.addEventListener('click', this._onCloseClick);
          }
          return;
        }
      }
    } catch { /* ignore */ }

    const root = document.createElement('div');
    root.className = 'kp-floating-keyboard-help';
    root.hidden = true;
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-label', 'KeyPilot keyboard reference');

    // Keep styling mostly inline to avoid depending on any page CSS.
    Object.assign(root.style, {
      position: 'fixed',
      left: '16px',
      bottom: '16px',
      width: '740px',
      maxWidth: 'calc(100vw - 24px)',
      maxHeight: 'calc(100vh - 24px)',
      overflow: 'auto',
      zIndex: String(Z_INDEX.FLOATING_KEYBOARD_HELP),
      background: 'rgba(20, 20, 20, 0.92)',
      color: 'rgba(255,255,255,0.95)',
      border: '1px solid rgba(255,255,255,0.12)',
      borderRadius: '12px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.4)',
      /* backdrop-filter removed to prevent Chrome z-index stacking context bug */
      fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
      pointerEvents: 'auto'
      /* Note: position: fixed creates a positioning context for absolute children */
    });
    // Match popup.html theme tokens so the floating keyboard looks identical.
    applyPopupThemeVars(root);

    const header = document.createElement('div');
    Object.assign(header.style, {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '12px',
      padding: '10px 12px',
      borderBottom: '1px solid rgba(255,255,255,0.1)'
    });

    const title = document.createElement('div');
    title.textContent = 'KeyPilot keyboard reference';
    Object.assign(title.style, {
      fontSize: '13px',
      fontWeight: '600',
      letterSpacing: '0.2px'
    });

    const hint = document.createElement('div');
    hint.textContent = 'Press K to toggle';
    Object.assign(hint.style, {
      marginLeft: 'auto',
      fontSize: '12px',
      fontWeight: '500',
      opacity: '0.8'
    });

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '×';
    closeBtn.setAttribute('aria-label', 'Close keyboard reference');
    Object.assign(closeBtn.style, {
      width: '28px',
      height: '28px',
      borderRadius: '8px',
      border: '1px solid rgba(255,255,255,0.18)',
      background: 'rgba(255,255,255,0.06)',
      color: 'rgba(255,255,255,0.95)',
      cursor: 'pointer',
      fontSize: '18px',
      lineHeight: '26px',
      padding: '0',
      flex: '0 0 auto'
    });
    closeBtn.addEventListener('click', this._onCloseClick);

    header.appendChild(title);
    header.appendChild(hint);
    header.appendChild(closeBtn);

    const body = document.createElement('div');
    Object.assign(body.style, {
      padding: '10px 12px'
    });

    const keyboardContainer = document.createElement('div');
    keyboardContainer.className = 'kp-floating-keyboard-help__keyboard';
    body.appendChild(keyboardContainer);

    root.appendChild(header);
    root.appendChild(body);

    // Attach to DOM.
    (document.body || document.documentElement).appendChild(root);

    this.root = root;
    this.keyboardContainer = keyboardContainer;
    this.closeBtn = closeBtn;
  }

  _render() {
    if (!this.keyboardContainer) return;
    try {
      renderKeybindingsKeyboard({ container: this.keyboardContainer, keybindings: this.keybindings });
    } catch (e) {
      // In case a page CSP / DOM edge case breaks rendering, fail gracefully.
      this.keyboardContainer.textContent = 'Unable to render keyboard reference on this page.';
      console.warn('[KeyPilot] Failed to render floating keyboard reference:', e);
    }
  }

  _onCloseClick(e) {
    try {
      e.preventDefault();
      e.stopPropagation();
    } catch { /* ignore */ }
    // Closing the panel should behave like pressing "K":
    // it must update KeyPilot's persisted visibility state, not only hide the DOM.
    try {
      const kp = window?.__KeyPilotInstance;
      if (kp && typeof kp.applyKeyboardHelpVisibility === 'function') {
        kp.applyKeyboardHelpVisibility(false, { persist: true });
        return;
      }
    } catch { /* ignore */ }

    // Fallback: still hide if KeyPilot isn't available for some reason.
    this.hide();
  }
}

// Debug: Make sure class is available globally for bundled version
if (typeof window !== 'undefined') {
  window.FloatingKeyboardHelp = FloatingKeyboardHelp;
}


