/**
 * Application state management
 */
import { MODES } from '../config/constants.js';

export class StateManager {
  constructor() {
    this.state = {
      mode: MODES.NONE,
      lastMouse: { x: 0, y: 0 },
      focusEl: null,
      deleteEl: null,
      highlightEl: null,
      highlightStartPosition: null,
      currentSelection: null,
      isInitialized: false,
      popoverOpen: false,
      popoverUrl: null
    };
    
    this.subscribers = new Set();
  }

  getState() {
    return { ...this.state };
  }

  setState(updates) {
    const prevState = { ...this.state };
    this.state = { ...this.state, ...updates };
    
    // Notify subscribers of state changes
    this.notifySubscribers(prevState, this.state);
  }

  subscribe(callback) {
    this.subscribers.add(callback);
    
    // Return unsubscribe function
    return () => {
      this.subscribers.delete(callback);
    };
  }

  notifySubscribers(prevState, newState) {
    for (const callback of this.subscribers) {
      try {
        callback(newState, prevState);
      } catch (error) {
        console.error('State subscriber error:', error);
      }
    }
  }

  // Convenience methods
  setMode(mode) {
    this.setState({ mode });
  }

  setMousePosition(x, y) {
    this.setState({ lastMouse: { x, y } });
  }

  setFocusElement(element) {
    this.setState({ focusEl: element });
  }

  setDeleteElement(element) {
    this.setState({ deleteEl: element });
  }

  setHighlightElement(element) {
    this.setState({ highlightEl: element });
  }

  setHighlightStartPosition(position) {
    this.setState({ highlightStartPosition: position });
  }

  setCurrentSelection(selection) {
    this.setState({ currentSelection: selection });
  }

  setPopoverOpen(isOpen, url = null) {
    if (isOpen) {
      this.setState({ 
        mode: MODES.POPOVER,  // Set mode when opening
        popoverOpen: isOpen, 
        popoverUrl: url 
      });
    } else {
      this.setState({ 
        mode: MODES.NONE,  // Reset mode when closing
        popoverOpen: false, 
        popoverUrl: null 
      });
    }
  }

  clearElements() {
    this.setState({ 
      focusEl: null, 
      deleteEl: null,
      highlightEl: null,
      highlightStartPosition: null,
      currentSelection: null
    });
  }

  isDeleteMode() {
    return this.state.mode === MODES.DELETE;
  }

  isHighlightMode() {
    return this.state.mode === MODES.HIGHLIGHT;
  }

  isTextFocusMode() {
    return this.state.mode === MODES.TEXT_FOCUS;
  }

  isPopoverMode() {
    return this.state.mode === MODES.POPOVER;
  }

  reset() {
    this.setState({
      mode: MODES.NONE,
      focusEl: null,
      deleteEl: null,
      highlightEl: null,
      highlightStartPosition: null,
      currentSelection: null,
      popoverOpen: false,
      popoverUrl: null
    });
  }
}