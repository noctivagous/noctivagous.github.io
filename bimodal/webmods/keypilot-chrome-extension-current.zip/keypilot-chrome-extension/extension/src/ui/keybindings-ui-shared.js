/**
 * Shared pieces of the KeyPilot keybindings UI that need to stay consistent
 * across:
 * - bundled content UI (`src/ui/keybindings-ui.js`)
 * - early injection UI (`extension/early-inject.js`)
 *
 * NOTE: `early-inject.js` cannot import ESM at runtime (it must run at
 * `document_start` and is loaded directly by the manifest). Instead, the build
 * script stamps generated constants into `early-inject.js` from this module.
 */

export const KEYBINDINGS_UI_STYLE_ATTR = 'data-kp-keybindings-ui-style';

/**
 * Canonical keyboard layout used by both early-inject and the bundled UI.
 * Action keys reference IDs in `KEYBINDINGS`.
 */
export const KEYBINDINGS_KEYBOARD_LAYOUT = [
  [
    { type: 'special', text: 'Tab', className: 'key key-tab' },
    { type: 'action', id: 'TAB_LEFT', fallbackText: 'Tab Left' },
    { type: 'action', id: 'TAB_RIGHT', fallbackText: 'Tab Right' },
    { type: 'action', id: 'OPEN_POPOVER', fallbackText: 'Open Popover' },
    { type: 'action', id: 'FORWARD', fallbackText: 'Go Forward' },
    { type: 'action', id: 'NEW_TAB', fallbackText: 'New Tab' },
    { type: 'key', text: 'Y' },
    { type: 'key', text: 'U' },
    { type: 'key', text: 'I' },
    { type: 'key', text: 'O' },
    { type: 'key', text: 'P' },
    { type: 'key', text: '[' },
    { type: 'key', text: ']' },
    { type: 'action', id: 'DELETE', fallbackText: 'Delete Mode', className: 'key key-backspace' }
  ],
  [
    { type: 'special', text: 'Caps', className: 'key key-caps' },
    { type: 'key', text: 'A' },
    { type: 'action', id: 'BACK2', fallbackText: 'Go Back' },
    { type: 'action', id: 'BACK', fallbackText: 'Go Back' },
    { type: 'action', id: 'ACTIVATE', fallbackText: 'Click Element' },
    { type: 'action', id: 'ACTIVATE_NEW_TAB', fallbackText: 'Click New Tab' },
    { type: 'key', text: 'H' },
    { type: 'key', text: 'J' },
    // K is a KeyPilot action: toggle the floating keyboard help (persisted).
    { type: 'action', id: 'TOGGLE_KEYBOARD_HELP', fallbackText: 'KB Reference' },
    { type: 'key', text: 'L' },
    { type: 'key', text: ';' },
    { type: 'key', text: "'" },
    { type: 'special', text: 'Enter', className: 'key key-enter' }
  ],
  [
    { type: 'special', text: 'Shift', className: 'key key-shift' },
    { type: 'action', id: 'PAGE_UP', fallbackText: 'Page Up' },
    { type: 'action', id: 'PAGE_DOWN', fallbackText: 'Page Down' },
    { type: 'action', id: 'PAGE_UP_INSTANT', fallbackText: 'Page Up Fast' },
    { type: 'action', id: 'PAGE_DOWN_INSTANT', fallbackText: 'Page Down Fast' },
    { type: 'action', id: 'PAGE_TOP', fallbackText: 'Scroll To Top' },
    { type: 'action', id: 'PAGE_BOTTOM', fallbackText: 'Scroll To Bottom' },
    { type: 'key', text: 'M' },
    { type: 'key', text: ',' },
    { type: 'key', text: '.' },
    { type: 'action', id: 'CLOSE_TAB', fallbackText: 'Close Tab' },
    { type: 'special', text: 'Shift', className: 'key key-shift' }
  ]
];

/**
 * Generate the injected CSS used by the keyboard UI (both early + bundled).
 *
 * @param {Object} params
 * @param {number} params.zKeybindingsPopover
 */
export function getKeybindingsUiCss({ zKeybindingsPopover }) {
  const z = Number.isFinite(zKeybindingsPopover) ? zKeybindingsPopover : Number(zKeybindingsPopover);
  const zIndex = Number.isFinite(z) ? z : 1000010;

  return `
/* KeyPilot Keybindings UI (injected) */
.keyboard-visual {
  background: var(--surface);
  border-radius: 8px;
  padding: 1px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 10px;
  line-height: 1.1;
  user-select: none;
  border: 1px solid var(--border);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
  width: 100%;
  box-sizing: border-box;
}

.keyboard-row {
  display: flex;
  justify-content: center;
  margin-bottom: 4px;
  gap: 2px;
  width: 100%;
}

.keyboard-row:last-child {
  margin-bottom: 0;
}

.key {
  position: relative;
  background: var(--surface-light);
  border: 2px solid black;
  border-radius: 6px;
  min-width: 28px;
  min-height: 49px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--fg);
  text-align: center;
  padding: 2px 3px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  transition: all 0.1s ease;
  font-size: 10px;
  line-height: 1.2;
  flex: 1;
  word-wrap: break-word;
  overflow-wrap: break-word;
  text-shadow: 1px 1px 2px #333;
  color: black;
}

.key:hover {
  background: var(--surface);
  border-color: var(--border2);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.key .key-main {
  padding-bottom: 10px; /* room for .key-label overlay */
}

.key.key-tab { flex: 1.2; }
.key.key-tab-right { flex: 1; }
.key.key-caps { flex: 1.3; }
.key.key-enter { flex: 1.4; }
.key.key-shift { flex: 1.5; }
.key.key-space { flex: 6; min-width: 120px; }
.key.key-backspace { flex: 1.7; }

/* Action-specific keys */
.key.key-activate,
.key.key-activate-new,
.key.key-delete,
.key.key-back,
.key.key-forward,
.key.key-highlight,
.key.key-rect-highlight,
.key.key-new-tab,
.key.key-page-up,
.key.key-page-down,
.key.key-page-up-instant,
.key.key-page-down-instant,
.key.key-scroll-top,
.key.key-scroll-bottom,
.key.key-close-tab,
.key.key-open-popover {
  flex: 1.1;
}

.key-label {
  position: absolute;
  bottom: 1px;
  right: 2px;
  font-size: 12px;
  opacity: 0.9;
  font-weight: bold;
  line-height: 1;
  text-shadow: 1px 1px 2px #333;
  color: black;
}

/* KeyPilot action key color coding */
.key.key-activate,
.key.key-activate-new {
  background: linear-gradient(135deg, var(--ok) 0%, #059669 100%);
  color: white;
}

.key.key-tab,
.key.key-tab-right,
.key.key-new-tab,
.key.key-open-popover {
  background: linear-gradient(135deg, var(--ok) 0%, #059669 100%);
  color: white;
}

.key.key-back,
.key.key-forward,
.key.key-scroll-top,
.key.key-scroll-bottom {
  background: linear-gradient(135deg, var(--brand) 0%, var(--brand-dark) 100%);
  color: white;
}

.key.key-page-up,
.key.key-page-down,
.key.key-page-up-instant,
.key.key-page-down-instant {
  background: linear-gradient(135deg, var(--ok) 0%, #059669 100%);
  color: white;
}

.key.key-delete,
.key.key-close-tab {
  background: linear-gradient(135deg, var(--err) 0%, #dc2626 100%);
  color: white;
}

.key.key-highlight,
.key.key-rect-highlight {
  background: linear-gradient(135deg, var(--warn) 0%, #f59e0b 100%);
  color: white;
}

/* Keep the overlay label readable on colored keys */
.key.key-activate .key-label,
.key.key-activate-new .key-label,
.key.key-tab .key-label,
.key.key-tab-right .key-label,
.key.key-new-tab .key-label,
.key.key-open-popover .key-label,
.key.key-back .key-label,
.key.key-forward .key-label,
.key.key-scroll-top .key-label,
.key.key-scroll-bottom .key-label,
.key.key-page-up .key-label,
.key.key-page-down .key-label,
.key.key-page-up-instant .key-label,
.key.key-page-down-instant .key-label,
.key.key-delete .key-label,
.key.key-close-tab .key-label,
.key.key-highlight .key-label,
.key.key-rect-highlight .key-label {
  color: white;
}

/* Popover (tooltip) shown when clicking a key */
.kp-keybindings-popover {
  position: absolute;
  z-index: ${zIndex};
  max-width: 280px;
  background: var(--surface);
  color: var(--fg);
  border: 1px solid var(--border);
  border-radius: 10px;
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.45);
  padding: 10px 12px;
  font-size: 12px;
  line-height: 1.35;
  /* Position absolute relative to parent container avoids z-index stacking context issues */
}

.kp-keybindings-popover[hidden] { display: none; }

.kp-keybindings-popover .kp-popover-title {
  font-weight: 700;
  margin: 0 0 4px 0;
  color: var(--fg);
}

.kp-keybindings-popover .kp-popover-keys {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  color: var(--muted);
  margin: 0 0 6px 0;
  font-size: 11px;
}

.kp-keybindings-popover .kp-popover-desc {
  margin: 0;
  color: var(--fg);
  opacity: 0.95;
}

.kp-keybindings-popover::before {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  left: var(--kp-arrow-left, 18px);
  border: 9px solid transparent;
}

.kp-keybindings-popover[data-placement="top"]::before {
  top: 100%;
  border-top-color: var(--border);
}

.kp-keybindings-popover[data-placement="top"]::after {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  left: var(--kp-arrow-left, 18px);
  top: calc(100% - 1px);
  border: 8px solid transparent;
  border-top-color: var(--surface);
}

.kp-keybindings-popover[data-placement="bottom"]::before {
  bottom: 100%;
  border-bottom-color: var(--border);
}

.kp-keybindings-popover[data-placement="bottom"]::after {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  left: var(--kp-arrow-left, 18px);
  bottom: calc(100% - 1px);
  border: 8px solid transparent;
  border-bottom-color: var(--surface);
}
`;
}


